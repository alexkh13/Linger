angular.module("linger.controllers").controller("CreateController", [ "$scope", "$state", "$stateParams", "$location", function ($scope, $state, $stateParams, $location) {



}]);

