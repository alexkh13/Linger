angular.module("linger.controllers").controller("FriendsViewController", [ "$scope", "$q", "$http", "$state", "lingerAPI", function ($scope, $q, $http, $state, lingerAPI) {
    
}]);
