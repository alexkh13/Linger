angular.module("linger.controllers").controller("LoginController", [ "$scope", "$window", "$cordovaFacebook", "$location", function ($scope, $window, $cordovaFacebook, $location) {

    $scope.loginFacebook = function() {
        $cordovaFacebook.login(['user_about_me', 'user_friends'])
            .then(function(success) {
                debugger
            }, function (error) {
                // error
            });
    }

}]);



